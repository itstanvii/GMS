import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './user.model';
import { Trainer } from './trainer.model';
import { Store } from './store.model';

const PROTOCOL = 'http';
const PORT = 3500;

@Injectable({
  providedIn: 'root',
})
export class RestDataSource {
  baseUrl: string;

  constructor(private http: HttpClient) {
    this.baseUrl = `${PROTOCOL}://${location.hostname}:${PORT}`;
  }
  saveUser(user: User): Observable<User> {
    return this.http.post<User>(this.baseUrl + '/user', user);
  }

  getAllUsers(): Observable<any[]> {
    // console.log(this.baseUrl + 'products');
    return this.http.get<User[]>(this.baseUrl + '/user');
  }
  getUserByCredentials(email: string, password: string): Observable<User[]> {
    return this.http.get<User[]>(this.baseUrl + '/user', {
      params: { email, password },
    });
  }
  saveTrainer(trainer: Trainer) {
    return this.http.post<Trainer>(this.baseUrl + '/trainer', trainer);
  }
  getAllTrainers(): Observable<Trainer[]> {
    return this.http.get<Trainer[]>(`${this.baseUrl}/trainer`);
  }

  updateUser(id: string, user: User): Observable<User> {
    return this.http.put<User>(`${this.baseUrl}/user/${id}`, user);
  }
  saveProduct(product: Store): Observable<Store> {
    return this.http.post<Store>(`${this.baseUrl}/items`, product);
  }

  deleteProduct(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/items/${id}`);
  }
  deleteUser(id?: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/user/${id}`);
  }
  deleteTrainer(id?: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/trainer/${id}`);
  }
  updateProduct(product: Store): Observable<Store> {
    return this.http.put<Store>(`${this.baseUrl}/items/${product.id}`, product);
  }
  getProducts(): Observable<Store[]> {
    return this.http.get<Store[]>(`${this.baseUrl}/items`);
  }
}
