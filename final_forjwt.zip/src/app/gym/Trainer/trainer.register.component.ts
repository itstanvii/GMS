import { Component } from '@angular/core';
import { Trainer } from '../../model/trainer.model';
import { Router } from '@angular/router';
import { Repository } from '../../model/repository';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';

@Component({
  selector: 'trainer-register',
  templateUrl: 'trainer.register.component.html',
})
export class TrainerRegisterComponent {
  trainerForm!: FormGroup;
  trainer: Trainer = new Trainer();

  constructor(
    private router: Router,
    private repository: Repository,
    private fb: FormBuilder
  ) {}
  ngOnInit(): void {
    this.trainerForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      specialization: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      experience: [
        '',
        [Validators.required, Validators.min(0), Validators.max(50)],
      ],
      certifications: [
        '',
        [Validators.required, Validators.min(1), Validators.max(10)],
      ],
    });
  }

  save() {
    if (this.trainerForm.valid) {
      const formData = this.trainerForm.value;
      this.repository.saveTrainers(formData);
      this.router.navigate(['/home']);
      console.log('Trainer saved:', this.trainer);
    } else {
      console.log('Form is invalid');
    }
  }
}
