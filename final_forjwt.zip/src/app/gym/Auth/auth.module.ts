import { AllUsersComponent } from './allUsers.component';
import { AdminComponent } from './admin.component';
import { AuthComponent } from './auth.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { UserComponent } from '../User/user.component';
import { AdminAddComponent } from './adminAdd.component';
import { AdminDeleteComponent } from './adminDelete.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    RouterModule.forChild([
      {
        path: 'adminLogin',
        component: AuthComponent,
      },
      {
        path: 'remove',
        component: AdminDeleteComponent,
      },
      {
        path: 'edit',
        component: AdminAddComponent,
      },
      {
        path: 'view-user',
        component: AllUsersComponent,
      },
      {
        path: 'admin',
        component: AdminComponent,
      },
    ]),
  ], // Dependency Modules
  providers: [],
  declarations: [
    AuthComponent,
    AdminComponent,
    AdminDeleteComponent,
    AdminAddComponent,
    AllUsersComponent,
  ],
})
export class AuthModule {} // lazy loaded.
