export class Orders {
  constructor(
    private orderId: string,
    private id?: string,
    private name?: string,
    private email?: string,
    private address?: string,
    public cart?: { productId: string; quantity: number }[]
  ) {}
}
