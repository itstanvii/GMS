import { Repository } from './repository';
import { RestDataSource } from './restDataSource';
import { NgModule } from '@angular/core';

@NgModule({
  imports: [],
  exports: [],
  declarations: [],
  providers: [RestDataSource, Repository],
})
export class modelModule {}
