const jwt = require("jsonwebtoken");

const APP_SECRET = "myappsecret";
const USERNAME = "admin";
const PASSWORD = "secret";

const mappings = {
  get: ["/user", "/trainer"],
  post: ["/user", "/trainer"],
};

function requiresAuth(method, url) {
  return (
    (mappings[method.toLowerCase()] || []).find((p) => url.startsWith(p)) !==
    undefined
  );
}

module.exports = function (req, res, next) {
  // Login route
  if (req.url.endsWith("/login") && req.method === "POST") {
    if (
      req.body &&
      req.body.name === USERNAME &&
      req.body.password === PASSWORD
    ) {
      const token = jwt.sign({ data: USERNAME }, APP_SECRET, {
        expiresIn: "1h",
      });
      res.json({ success: true, token: token });
    } else {
      res.json({ success: false });
    }
    return;
  }

  // Protected routes
  if (requiresAuth(req.method, req.url)) {
    let token = req.headers["authorization"] || "";
    if (token.startsWith("Bearer ")) {
      token = token.slice(7); // remove "Bearer " prefix
      try {
        jwt.verify(token, APP_SECRET);
        next();
        return;
      } catch (err) {
        console.error("JWT verification failed:", err.message);
      }
    }
    res.statusCode = 401;
    res.end("Unauthorized");
    return;
  }

  // Public routes
  next();
};
