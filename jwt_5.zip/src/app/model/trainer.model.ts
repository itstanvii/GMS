export class Trainer {
  constructor(
    public id?: string,
    public name?: string,
    public email?: string,
    public password?: string,
    public experience?: number,
    public certifications?: number,
    public specialization?: string
  ) {}
}
